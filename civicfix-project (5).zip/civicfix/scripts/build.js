// Copies the static app (index.html + public/) into dist/ for deployment.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const dist = path.join(root, 'dist');

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });
fs.copyFileSync(path.join(root, 'index.html'), path.join(dist, 'index.html'));
const pub = path.join(root, 'public');
if (fs.existsSync(pub)) fs.cpSync(pub, dist, { recursive: true });

const html = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
if (!html.includes('<title>Civic Fix</title>') || !html.includes('function cmap(')) {
  throw new Error('Build check failed: index.html does not look like the CivicFix app.');
}
console.log('Built dist/index.html (' + Math.round(html.length / 1024) + ' KB)');
