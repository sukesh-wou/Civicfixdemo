# CivicFix

**Report it. Track it. Fix it.** A mobile-first web app for reporting and tracking local civic problems in India.

This is a prototype built as a single static page (`index.html`) with no runtime dependencies and no backend.

## Features

- Intro screen with the Civic Fix poster and a Next button
- Aadhaar number and OTP sign-in (demo), then name and age
- English, Hindi and Telugu labels
- Six dashboard sections: Report, Track, City map, Accountability, AI bot, Community
- Report: photo capture, live location, problem type, emergency flag, duplicate check with "Raise" instead of re-reporting
- Track: four-stage status for your reports and the ones you raised
- City map: outline map of India with real coordinates, India / Region / Street zoom, city shortcuts and problem pins
- Accountability dashboard: resolved rate and open / urgent counts, per-team table, longest pending
- AI bot: keyword-based problem type, team and urgency, with a "Report this" shortcut
- Community power: points, ward goal, leaderboard, problems that need support, demo donate card
- Officer demo (corporator, civil, electrical, sanitation) that updates reports shown in the citizen view

## Project structure

```
civicfix/
├── index.html          The whole app (HTML, CSS, JavaScript, embedded images)
├── public/
│   └── robots.txt      Copied as-is to the site root
├── scripts/
│   ├── build.js        Copies index.html and public/ into dist/
│   └── serve.js        Tiny local server for dist/
├── package.json
├── vercel.json         Vercel build, output folder and security headers
├── .gitignore
└── README.md
```

There are no npm dependencies, so `npm install` is not required.

## Run locally

Requires Node.js 18 or newer.

```bash
npm run build     # creates dist/
npm start         # builds, then serves http://localhost:3000
```

You can also open `index.html` directly in a browser. Camera and location need `https://` or `http://localhost`.

## Publish on GitHub

```bash
git init
git add .
git commit -m "CivicFix: initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/civicfix.git
git push -u origin main
```

Create the empty `civicfix` repository on GitHub first (do not add a README or .gitignore there).

## Deploy on Vercel

**From the dashboard**

1. Go to https://vercel.com/new and import the GitHub repository.
2. Leave the settings as detected. `vercel.json` already sets Build Command `npm run build` and Output Directory `dist`, with Framework Preset "Other".
3. Click **Deploy**. Every push to `main` redeploys automatically.

**From the command line**

```bash
npx vercel          # preview deployment
npx vercel --prod   # production deployment
```

## Important notes about this prototype

- **Demo only.** No SMS is sent: the OTP is shown on screen. Real Aadhaar verification needs a licensed provider (AUA/KUA) and a backend. Do not collect real Aadhaar numbers in a public deployment.
- **Data stays on the device.** Reports, points and profile are stored in the browser's localStorage. Nothing is sent to a server, and clearing browser data removes it.
- **Sample data.** Nearby problems, leaderboard names and counters are fictional sample data.
- **Map.** The City map is a simplified outline of India drawn from coordinates, with no street tiles. For official use, follow the Survey of India map. Street-level maps (for example Leaflet with OpenStreetMap) can be added once the app is hosted on your own domain.
- **AI bot.** It matches keywords in the text. Photo recognition would need a server-side model.
- **External resource.** Fonts load from Google Fonts. Everything else, including the two images, is embedded in `index.html`.
- No API keys, passwords or environment variables are used or needed.

## Next steps for a production version

Backend and database for reports, real OTP and identity verification, an officer login with roles, notifications, real map tiles, and server-side image recognition.
